#超轻量级日志查看系统
本项目可单独部署，也可集成到其他项目中。
后续会推出监控多个平台系统的版本，敬请期待
##使用说明
有两种使用方式，单独部署&集成到项目中。
本文只说单独部署：
###修改config.txt文件
修改resources下边config.txt文件，改为将要查看日志的项目的日志路径即可
###修改index.html
路径改为tomcat的访问路径
测试访问路径：http://webao.bighongbao.com/otalog/

##说明
本项目参考oschina的开源项目https://github.com/wucao/websocket-tail-demo
